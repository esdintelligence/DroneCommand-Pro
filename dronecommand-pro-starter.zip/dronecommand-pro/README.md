# DroneCommand Pro
Starter monorepo skeleton for web (React), api (NestJS), mobile (Expo).
